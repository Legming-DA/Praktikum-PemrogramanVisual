﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class TUGAS1_2118118
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtNilai1 = New System.Windows.Forms.TextBox()
        Me.txtNilai2 = New System.Windows.Forms.TextBox()
        Me.txtHasil1 = New System.Windows.Forms.TextBox()
        Me.txtHasil2 = New System.Windows.Forms.TextBox()
        Me.txtHasil3 = New System.Windows.Forms.TextBox()
        Me.btnKonversi1 = New System.Windows.Forms.Button()
        Me.btnKonversi2 = New System.Windows.Forms.Button()
        Me.btnReverse = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(60, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(120, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "PROGRAM KONVERSI"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(8, 43)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(42, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Nilai 1 :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(8, 70)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(42, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Nilai 2 :"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(9, 150)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(80, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Hasil Konversi :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(9, 221)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(80, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Hasil Konversi :"
        '
        'txtNilai1
        '
        Me.txtNilai1.Location = New System.Drawing.Point(103, 43)
        Me.txtNilai1.Name = "txtNilai1"
        Me.txtNilai1.Size = New System.Drawing.Size(133, 20)
        Me.txtNilai1.TabIndex = 5
        '
        'txtNilai2
        '
        Me.txtNilai2.Location = New System.Drawing.Point(103, 70)
        Me.txtNilai2.Name = "txtNilai2"
        Me.txtNilai2.Size = New System.Drawing.Size(133, 20)
        Me.txtNilai2.TabIndex = 6
        '
        'txtHasil1
        '
        Me.txtHasil1.Location = New System.Drawing.Point(103, 147)
        Me.txtHasil1.Name = "txtHasil1"
        Me.txtHasil1.Size = New System.Drawing.Size(133, 20)
        Me.txtHasil1.TabIndex = 7
        '
        'txtHasil2
        '
        Me.txtHasil2.Location = New System.Drawing.Point(103, 218)
        Me.txtHasil2.Name = "txtHasil2"
        Me.txtHasil2.Size = New System.Drawing.Size(133, 20)
        Me.txtHasil2.TabIndex = 8
        '
        'txtHasil3
        '
        Me.txtHasil3.Location = New System.Drawing.Point(103, 292)
        Me.txtHasil3.Name = "txtHasil3"
        Me.txtHasil3.Size = New System.Drawing.Size(133, 20)
        Me.txtHasil3.TabIndex = 9
        '
        'btnKonversi1
        '
        Me.btnKonversi1.Location = New System.Drawing.Point(12, 109)
        Me.btnKonversi1.Name = "btnKonversi1"
        Me.btnKonversi1.Size = New System.Drawing.Size(224, 23)
        Me.btnKonversi1.TabIndex = 10
        Me.btnKonversi1.Text = "Konversi dalam Bentuk Integer"
        Me.btnKonversi1.UseVisualStyleBackColor = True
        '
        'btnKonversi2
        '
        Me.btnKonversi2.Location = New System.Drawing.Point(12, 180)
        Me.btnKonversi2.Name = "btnKonversi2"
        Me.btnKonversi2.Size = New System.Drawing.Size(224, 23)
        Me.btnKonversi2.TabIndex = 11
        Me.btnKonversi2.Text = "Konversi dalam Bentuk String"
        Me.btnKonversi2.UseVisualStyleBackColor = True
        '
        'btnReverse
        '
        Me.btnReverse.Location = New System.Drawing.Point(11, 251)
        Me.btnReverse.Name = "btnReverse"
        Me.btnReverse.Size = New System.Drawing.Size(225, 23)
        Me.btnReverse.TabIndex = 12
        Me.btnReverse.Text = "Reverse"
        Me.btnReverse.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(12, 295)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(80, 13)
        Me.Label6.TabIndex = 13
        Me.Label6.Text = "Hasil Konversi :"
        '
        'TUGAS1_2118118
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(251, 327)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.btnReverse)
        Me.Controls.Add(Me.btnKonversi2)
        Me.Controls.Add(Me.btnKonversi1)
        Me.Controls.Add(Me.txtHasil3)
        Me.Controls.Add(Me.txtHasil2)
        Me.Controls.Add(Me.txtHasil1)
        Me.Controls.Add(Me.txtNilai2)
        Me.Controls.Add(Me.txtNilai1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "TUGAS1_2118118"
        Me.Text = "2118118_TUGAS 1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtNilai1 As System.Windows.Forms.TextBox
    Friend WithEvents txtNilai2 As System.Windows.Forms.TextBox
    Friend WithEvents txtHasil1 As System.Windows.Forms.TextBox
    Friend WithEvents txtHasil2 As System.Windows.Forms.TextBox
    Friend WithEvents txtHasil3 As System.Windows.Forms.TextBox
    Friend WithEvents btnKonversi1 As System.Windows.Forms.Button
    Friend WithEvents btnKonversi2 As System.Windows.Forms.Button
    Friend WithEvents btnReverse As System.Windows.Forms.Button
    Friend WithEvents Label6 As System.Windows.Forms.Label
End Class
